from pymongo import MongoClient
client = MongoClient('mongodb+srv://user1:SVH6LIa03J5mL6TZ@cluster0.f3jvjyn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0&authMechanism=SCRAM-SHA-1&authSource=SVH6LIa03J5mL6TZ')
db = client['user1']