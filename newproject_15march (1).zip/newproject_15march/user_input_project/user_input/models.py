# user_input/models.py
from django.db import models

class UserInput(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    school = models.CharField(max_length=100)

    def __str__(self):
        return str(self.name)
   
