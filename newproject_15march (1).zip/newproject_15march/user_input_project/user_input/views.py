# user_input/views.py
from django.shortcuts import render, redirect
from .forms import UserInputForm

def input_form(request):
    if request.method == 'POST':
        form = UserInputForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('success')  # Redirect to a success page
    else:
        form = UserInputForm()
    return render(request, 'user_input/input_form.html', {'form': form})

def success(request):
    return render(request, 'user_input/success.html')
