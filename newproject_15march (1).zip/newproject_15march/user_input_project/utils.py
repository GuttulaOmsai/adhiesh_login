from pymongo import MongoClient

def get_db_handle(db_name, host, port, username, password):
    try:
        client = MongoClient(host=host,
                             port=int(port),
                             username=username,
                             password=password
                            )
        db_handle = client[db_name]  # Use db_name passed as argument
        return db_handle, client
    except Exception as e:
        print(f"Error connecting to MongoDB: {str(e)}")
        return None, None

# Example usage:
db_name = "user1"  # Your MongoDB database name
host = "localhost"  # MongoDB host address
port = "27017"      # MongoDB port
username = "user1"  # MongoDB username
password = "SVH6LIa03J5mL6TZ@cluster0"  # MongoDB password

db_handle, client = get_db_handle(db_name, host, port, username, password)
if db_handle:
    print("Connected to MongoDB successfully.")
else:
    print("Failed to connect to MongoDB.")
